from aiogram import Dispatcher


def register_admin_handlers(dp: Dispatcher):
    # todo: register all admin handlers
    pass
