from aiogram import Dispatcher


def register_user_handlers(dp: Dispatcher):
    # todo: register all user handlers
    pass

