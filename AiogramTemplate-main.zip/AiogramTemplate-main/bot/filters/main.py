from aiogram import Dispatcher


def register_all_filters(dp: Dispatcher):
    # todo: register all filters - dp.bind_filter()
    pass
