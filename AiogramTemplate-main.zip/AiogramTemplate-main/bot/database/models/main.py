def register_models() -> None:
    # todo: register models
    pass
